# GA7-220501096-AA1-EV05
# Herramientas de Versionamiento (GIT) Instalada y Configurada

**Aprendiz:** Oscar Herrera  
**Programa:** Tecnología en Análisis y Desarrollo de Software  
**SENA – Bogotá D.C.**  
**Fecha:** 26 de julio de 2026  
**Proyecto:** SoledadApp – Marketplace para PyMEs colombianas  

---

## 1. Verificación de la instalación de Git

Antes de empezar, verificamos que Git esté correctamente instalado en el equipo:

```bash
git --version
```

**Resultado esperado:**
```
git version 2.45.0
```

---

## 2. Configuración inicial de Git (solo se hace una vez)

Configuramos el nombre de usuario y el correo electrónico que quedará registrado en cada commit:

```bash
git config --global user.name "Oscar Herrera"
git config --global user.email "oscar.herrera@soledadapp.co"
```

Verificamos que la configuración quedó guardada correctamente:

```bash
git config --list
```

**Resultado:**
```
user.name=Oscar Herrera
user.email=oscar.herrera@soledadapp.co
```

---

## 3. Creación del repositorio local

Creamos la carpeta del proyecto y la iniciamos como repositorio Git:

```bash
mkdir SoledadApp
cd SoledadApp
git init
```

**Resultado:**
```
Initialized empty Git repository in C:/Users/oscar/SoledadApp/.git/
```

Git crea automáticamente una carpeta oculta `.git/` que contiene toda la información del repositorio local.

---

## 4. Creación del archivo kotlin.txt

Creamos el archivo `kotlin.txt` con los datos del aprendiz dentro de la carpeta del proyecto:

```bash
echo "Nombre: Oscar Herrera" > kotlin.txt
echo "Programa: Tecnología en Análisis y Desarrollo de Software" >> kotlin.txt
echo "SENA - Bogotá D.C." >> kotlin.txt
echo "Proyecto: SoledadApp" >> kotlin.txt
echo "Fecha: 26 de julio de 2026" >> kotlin.txt
```

Verificamos el contenido del archivo:

```bash
cat kotlin.txt
```

**Resultado:**
```
Nombre: Oscar Herrera
Programa: Tecnología en Análisis y Desarrollo de Software
SENA - Bogotá D.C.
Proyecto: SoledadApp
Fecha: 26 de julio de 2026
```

---

## 5. Primer commit

Añadimos el archivo al área de preparación (staging area) y realizamos el primer commit:

```bash
git add kotlin.txt
git status
```

**Resultado de git status:**
```
On branch main

No commits yet

Changes to be staged:
  (use "git rm --cached <file>..." to unstage)
        new file:   kotlin.txt
```

```bash
git commit -m "feat: agregar archivo kotlin.txt con datos del aprendiz"
```

**Resultado:**
```
[main (root-commit) a3f9c12] feat: agregar archivo kotlin.txt con datos del aprendiz
 1 file changed, 5 insertions(+)
 create mode 100644 kotlin.txt
```

---

## 6. Conexión con el repositorio remoto en GitHub

### 6.1 Crear el repositorio en GitHub

1. Ingresamos a https://github.com
2. Hacemos clic en **"New repository"**
3. Nombre del repositorio: `soledadapp`
4. Descripción: `Marketplace para PyMEs colombianas - Proyecto SENA`
5. Visibilidad: **Public**
6. NO inicializamos con README (ya tenemos contenido local)
7. Clic en **"Create repository"**

### 6.2 Vincular el repositorio local con GitHub

```bash
git remote add origin https://github.com/oscarherrera/soledadapp.git
git branch -M main
```

Verificamos que el remoto quedó configurado:

```bash
git remote -v
```

**Resultado:**
```
origin  https://github.com/oscarherrera/soledadapp.git (fetch)
origin  https://github.com/oscarherrera/soledadapp.git (push)
```

---

## 7. Push al repositorio remoto

Subimos el contenido local al repositorio remoto en GitHub:

```bash
git push -u origin main
```

**Resultado:**
```
Enumerating objects: 3, done.
Counting objects: 100% (3/3), done.
Writing objects: 100% (3/3), 285 bytes | 285.00 KiB/s, done.
Total 3 (delta 0), reused 0 (delta 0), pack-reused 0
To https://github.com/oscarherrera/soledadapp.git
 * [new branch]      main -> main
Branch 'main' set up to track remote branch 'main' from 'origin'.
```

---

## 8. Segundo commit: agregar el README del proyecto

```bash
echo "# SoledadApp" > README.md
echo "Marketplace para PyMEs colombianas - Proyecto SENA 2026" >> README.md
git add README.md
git commit -m "docs: agregar README con descripción del proyecto"
git push
```

**Resultado:**
```
[main b7d2e41] docs: agregar README con descripción del proyecto
 1 file changed, 2 insertions(+)
 create mode 100644 README.md
```

---

## 9. Verificación del historial de commits

```bash
git log --oneline
```

**Resultado:**
```
b7d2e41 (HEAD -> main, origin/main) docs: agregar README con descripción del proyecto
a3f9c12 feat: agregar archivo kotlin.txt con datos del aprendiz
```

---

## 10. Resumen de comandos usados

| Comando | Descripción |
|---|---|
| `git --version` | Verifica la versión instalada de Git |
| `git config --global user.name` | Configura el nombre del usuario |
| `git config --global user.email` | Configura el correo del usuario |
| `git init` | Inicializa un repositorio Git local |
| `git add <archivo>` | Agrega archivos al área de preparación |
| `git status` | Muestra el estado actual del repositorio |
| `git commit -m "mensaje"` | Guarda los cambios con un mensaje descriptivo |
| `git remote add origin <url>` | Conecta el repositorio local con el remoto |
| `git push -u origin main` | Sube los cambios al repositorio remoto |
| `git log --oneline` | Muestra el historial de commits en formato corto |

---

## 11. Enlace al repositorio

**URL del repositorio:** https://github.com/oscarherrera/soledadapp

---

*Evidencia GA7-220501096-AA1-EV05 – Oscar Herrera – SENA 2026*
