# SoledadApp – Módulo JDBC (GA7-220501096-AA2-EV01)

**Autor:** Oscar Herrera  
**Programa:** Tecnología en Análisis y Desarrollo de Software – SENA  
**Fecha:** 26 de julio de 2026  
**Repositorio:** https://github.com/oscarherrera/soledadapp  

---

## Descripción

Módulo de codificación con conexión a base de datos MySQL mediante JDBC.
Implementa operaciones CRUD completas sobre la entidad `Producto` del marketplace SoledadApp.

## Estructura del proyecto

```
SoledadApp-JDBC/
├── src/co/soledadapp/
│   ├── modelo/         → Producto.java (entidad)
│   ├── conexion/       → ConexionBD.java (Singleton JDBC)
│   ├── repositorio/    → ProductoRepositorio.java (CRUD)
│   └── Principal.java  → Clase de prueba
├── database.sql        → Script de base de datos
└── README.md
```

## Cómo ejecutar

1. Ejecutar `database.sql` en MySQL Workbench
2. Agregar `mysql-connector-j-8.x.x.jar` al classpath
3. Compilar y ejecutar `Principal.java`
