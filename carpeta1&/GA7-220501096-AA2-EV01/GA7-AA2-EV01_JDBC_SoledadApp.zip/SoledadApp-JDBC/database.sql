-- ============================================================
--  SoledadApp - Script de creación de base de datos
--  Autor: Oscar Herrera
--  Fecha: 26 de julio de 2026
-- ============================================================

-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS soledadapp
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_spanish_ci;

USE soledadapp;

-- ── Tabla: productos ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS productos (
    id_producto      INT          NOT NULL AUTO_INCREMENT,
    nombre_producto  VARCHAR(150) NOT NULL,
    categoria        VARCHAR(80)  NOT NULL,
    precio_venta     DOUBLE       NOT NULL DEFAULT 0,
    stock_disponible INT          NOT NULL DEFAULT 0,
    activo           TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (id_producto)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Datos de prueba ─────────────────────────────────────────
INSERT INTO productos (nombre_producto, categoria, precio_venta, stock_disponible, activo) VALUES
('Camiseta Oversize',  'Ropa',        89900,  45, 1),
('Auriculares BT',     'Electrónica', 249900, 12, 1),
('Silla Ergonómica',   'Hogar',       599900,  3, 1),
('Café Orgánico',      'Alimentos',    38900, 98, 1),
('Mochila Impermeable','Ropa',        179900, 27, 1),
('Teclado Mecánico',   'Electrónica', 389900,  8, 1);

-- ── Verificar los datos ─────────────────────────────────────
SELECT * FROM productos;
