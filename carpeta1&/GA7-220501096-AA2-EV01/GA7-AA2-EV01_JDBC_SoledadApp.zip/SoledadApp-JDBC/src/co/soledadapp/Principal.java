package co.soledadapp;

import co.soledadapp.conexion.ConexionBD;
import co.soledadapp.modelo.Producto;
import co.soledadapp.repositorio.ProductoRepositorio;

import java.util.List;

/**
 * Clase principal de prueba para demostrar el funcionamiento del módulo CRUD
 * del proyecto SoledadApp usando JDBC con MySQL.
 *
 * Ejecuta las cuatro operaciones básicas: insertar, listar, actualizar y eliminar.
 *
 * @author Oscar Herrera
 * @version 1.0
 * @since 2026-07-26
 */
public class Principal {

    public static void main(String[] args) {

        ProductoRepositorio repositorio = new ProductoRepositorio();

        System.out.println("========================================");
        System.out.println("   SoledadApp - Módulo CRUD Productos   ");
        System.out.println("========================================");

        // ── 1. INSERTAR ────────────────────────────────────────────────────
        System.out.println("\n[1] Insertando productos de prueba...");

        Producto p1 = new Producto(0, "Camiseta Oversize", "Ropa",     89900,  45, true);
        Producto p2 = new Producto(0, "Auriculares BT",   "Electrónica", 249900, 12, true);
        Producto p3 = new Producto(0, "Silla Ergonómica", "Hogar",     599900,  3, true);
        Producto p4 = new Producto(0, "Café Orgánico",    "Alimentos",  38900, 98, true);

        System.out.println("  Insertar p1: " + repositorio.insertar(p1));
        System.out.println("  Insertar p2: " + repositorio.insertar(p2));
        System.out.println("  Insertar p3: " + repositorio.insertar(p3));
        System.out.println("  Insertar p4: " + repositorio.insertar(p4));

        // ── 2. LISTAR TODOS ────────────────────────────────────────────────
        System.out.println("\n[2] Listando todos los productos:");
        List<Producto> productos = repositorio.listarTodos();
        if (productos.isEmpty()) {
            System.out.println("  No se encontraron productos.");
        } else {
            productos.forEach(p -> System.out.println("  " + p));
        }

        // ── 3. BUSCAR POR ID ───────────────────────────────────────────────
        System.out.println("\n[3] Buscando producto con ID = 1:");
        Producto encontrado = repositorio.buscarPorId(1);
        if (encontrado != null) {
            System.out.println("  Encontrado: " + encontrado);
        } else {
            System.out.println("  Producto no encontrado.");
        }

        // ── 4. ACTUALIZAR ──────────────────────────────────────────────────
        System.out.println("\n[4] Actualizando el producto con ID = 1...");
        if (encontrado != null) {
            encontrado.setPrecioVenta(79900);     // precio rebajado
            encontrado.setStockDisponible(60);    // stock reabastecido
            boolean actualizado = repositorio.actualizar(encontrado);
            System.out.println("  Actualización exitosa: " + actualizado);
            System.out.println("  Producto actualizado: " + repositorio.buscarPorId(1));
        }

        // ── 5. ELIMINAR ────────────────────────────────────────────────────
        System.out.println("\n[5] Eliminando el producto con ID = 4...");
        boolean eliminado = repositorio.eliminar(4);
        System.out.println("  Eliminación exitosa: " + eliminado);

        System.out.println("\n[6] Lista final de productos:");
        repositorio.listarTodos().forEach(p -> System.out.println("  " + p));

        // ── Cerrar conexión ────────────────────────────────────────────────
        ConexionBD.cerrarConexion();
        System.out.println("\n========================================");
        System.out.println("   Módulo CRUD finalizado correctamente  ");
        System.out.println("========================================");
    }
}
