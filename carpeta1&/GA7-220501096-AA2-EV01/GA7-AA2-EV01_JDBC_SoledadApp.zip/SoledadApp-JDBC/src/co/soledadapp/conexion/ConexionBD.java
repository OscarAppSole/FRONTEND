package co.soledadapp.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase utilitaria que gestiona la conexión a la base de datos MySQL
 * del proyecto SoledadApp mediante JDBC.
 *
 * Patrón: Singleton — garantiza que solo exista una conexión activa a la vez.
 *
 * Requisitos previos:
 *   - Tener MySQL Server instalado y en ejecución.
 *   - Haber creado la base de datos 'soledadapp' con el script SQL incluido.
 *   - Agregar el conector mysql-connector-j-8.x.x.jar al classpath del proyecto.
 *
 * @author Oscar Herrera
 * @version 1.0
 * @since 2026-07-26
 */
public class ConexionBD {

    // ── Parámetros de conexión ─────────────────────────────────────────────
    private static final String URL      = "jdbc:mysql://localhost:3306/soledadapp";
    private static final String USUARIO  = "root";
    private static final String PASSWORD = "soledadapp2026";
    private static final String DRIVER   = "com.mysql.cj.jdbc.Driver";

    // Instancia única (Singleton)
    private static Connection conexion = null;

    /**
     * Constructor privado para impedir la creación de instancias externas.
     */
    private ConexionBD() { }

    /**
     * Retorna una conexión activa a la base de datos.
     * Si no existe ninguna conexión abierta, la crea.
     *
     * @return Objeto Connection listo para ejecutar sentencias SQL.
     * @throws SQLException Si ocurre un error al establecer la conexión.
     */
    public static Connection obtenerConexion() throws SQLException {
        try {
            if (conexion == null || conexion.isClosed()) {
                Class.forName(DRIVER);
                conexion = DriverManager.getConnection(URL, USUARIO, PASSWORD);
                System.out.println("[OK] Conexión a la base de datos establecida.");
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver JDBC no encontrado: " + e.getMessage());
        }
        return conexion;
    }

    /**
     * Cierra la conexión activa a la base de datos de forma segura.
     */
    public static void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("[OK] Conexión cerrada correctamente.");
            }
        } catch (SQLException e) {
            System.err.println("[ERROR] Al cerrar la conexión: " + e.getMessage());
        }
    }
}
