package co.soledadapp.modelo;

/**
 * Clase que representa un producto del catálogo de SoledadApp.
 * Contiene los atributos básicos de un producto y sus métodos de acceso.
 *
 * @author Oscar Herrera
 * @version 1.0
 * @since 2026-07-26
 */
public class Producto {

    // ── Atributos privados ─────────────────────────────────────────────────
    private int    idProducto;
    private String nombreProducto;
    private String categoria;
    private double precioVenta;
    private int    stockDisponible;
    private boolean activo;

    // ── Constructores ──────────────────────────────────────────────────────

    /**
     * Constructor vacío requerido por frameworks y utilidades de reflexión.
     */
    public Producto() { }

    /**
     * Constructor completo para crear un producto con todos sus datos.
     *
     * @param idProducto       Identificador único del producto.
     * @param nombreProducto   Nombre descriptivo del producto.
     * @param categoria        Categoría a la que pertenece (Ropa, Electrónica, etc.).
     * @param precioVenta      Precio de venta al público.
     * @param stockDisponible  Cantidad de unidades disponibles en inventario.
     * @param activo           Indica si el producto está activo y visible en el catálogo.
     */
    public Producto(int idProducto, String nombreProducto, String categoria,
                    double precioVenta, int stockDisponible, boolean activo) {
        this.idProducto      = idProducto;
        this.nombreProducto  = nombreProducto;
        this.categoria       = categoria;
        this.precioVenta     = precioVenta;
        this.stockDisponible = stockDisponible;
        this.activo          = activo;
    }

    // ── Getters y Setters ──────────────────────────────────────────────────

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(double precioVenta) {
        this.precioVenta = precioVenta;
    }

    public int getStockDisponible() {
        return stockDisponible;
    }

    public void setStockDisponible(int stockDisponible) {
        this.stockDisponible = stockDisponible;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    // ── toString ───────────────────────────────────────────────────────────

    @Override
    public String toString() {
        return String.format(
            "Producto{id=%d, nombre='%s', categoria='%s', precio=%.2f, stock=%d, activo=%b}",
            idProducto, nombreProducto, categoria, precioVenta, stockDisponible, activo
        );
    }
}
