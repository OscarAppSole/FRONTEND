package co.soledadapp.repositorio;

import co.soledadapp.conexion.ConexionBD;
import co.soledadapp.modelo.Producto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Repositorio que implementa las operaciones CRUD (Crear, Leer, Actualizar,
 * Eliminar) sobre la tabla 'productos' de la base de datos de SoledadApp,
 * utilizando JDBC para la comunicación con MySQL.
 *
 * @author Oscar Herrera
 * @version 1.0
 * @since 2026-07-26
 */
public class ProductoRepositorio {

    // ── CREATE ─────────────────────────────────────────────────────────────

    /**
     * Inserta un nuevo producto en la base de datos.
     *
     * @param producto Objeto Producto con los datos a insertar.
     * @return true si la inserción fue exitosa, false en caso contrario.
     */
    public boolean insertar(Producto producto) {
        String sql = "INSERT INTO productos (nombre_producto, categoria, precio_venta, stock_disponible, activo) " +
                     "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, producto.getNombreProducto());
            ps.setString(2, producto.getCategoria());
            ps.setDouble(3, producto.getPrecioVenta());
            ps.setInt(4, producto.getStockDisponible());
            ps.setBoolean(5, producto.isActivo());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("[ERROR] Al insertar producto: " + e.getMessage());
            return false;
        }
    }

    // ── READ – todos ───────────────────────────────────────────────────────

    /**
     * Consulta todos los productos registrados en la base de datos.
     *
     * @return Lista de objetos Producto con todos los registros encontrados.
     */
    public List<Producto> listarTodos() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM productos ORDER BY id_producto ASC";

        try (Connection con = ConexionBD.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Producto p = mapearProducto(rs);
                lista.add(p);
            }

        } catch (SQLException e) {
            System.err.println("[ERROR] Al listar productos: " + e.getMessage());
        }

        return lista;
    }

    // ── READ – por ID ──────────────────────────────────────────────────────

    /**
     * Busca un producto específico por su identificador único.
     *
     * @param idProducto Identificador del producto a buscar.
     * @return Objeto Producto si fue encontrado, o null si no existe.
     */
    public Producto buscarPorId(int idProducto) {
        String sql = "SELECT * FROM productos WHERE id_producto = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idProducto);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearProducto(rs);
                }
            }

        } catch (SQLException e) {
            System.err.println("[ERROR] Al buscar producto por ID: " + e.getMessage());
        }

        return null;
    }

    // ── UPDATE ─────────────────────────────────────────────────────────────

    /**
     * Actualiza los datos de un producto existente en la base de datos.
     *
     * @param producto Objeto Producto con los nuevos datos (debe incluir idProducto).
     * @return true si la actualización fue exitosa, false en caso contrario.
     */
    public boolean actualizar(Producto producto) {
        String sql = "UPDATE productos SET nombre_producto = ?, categoria = ?, " +
                     "precio_venta = ?, stock_disponible = ?, activo = ? " +
                     "WHERE id_producto = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, producto.getNombreProducto());
            ps.setString(2, producto.getCategoria());
            ps.setDouble(3, producto.getPrecioVenta());
            ps.setInt(4, producto.getStockDisponible());
            ps.setBoolean(5, producto.isActivo());
            ps.setInt(6, producto.getIdProducto());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("[ERROR] Al actualizar producto: " + e.getMessage());
            return false;
        }
    }

    // ── DELETE ─────────────────────────────────────────────────────────────

    /**
     * Elimina un producto de la base de datos por su identificador.
     * Nota: en producción se recomienda usar baja lógica (activo = false)
     * en lugar de eliminación física para preservar el historial.
     *
     * @param idProducto Identificador del producto a eliminar.
     * @return true si la eliminación fue exitosa, false en caso contrario.
     */
    public boolean eliminar(int idProducto) {
        String sql = "DELETE FROM productos WHERE id_producto = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idProducto);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("[ERROR] Al eliminar producto: " + e.getMessage());
            return false;
        }
    }

    // ── Método privado auxiliar ────────────────────────────────────────────

    /**
     * Convierte una fila del ResultSet en un objeto Producto.
     *
     * @param rs ResultSet posicionado en la fila a mapear.
     * @return Objeto Producto con los datos de la fila.
     * @throws SQLException Si ocurre un error al leer los datos del ResultSet.
     */
    private Producto mapearProducto(ResultSet rs) throws SQLException {
        return new Producto(
            rs.getInt("id_producto"),
            rs.getString("nombre_producto"),
            rs.getString("categoria"),
            rs.getDouble("precio_venta"),
            rs.getInt("stock_disponible"),
            rs.getBoolean("activo")
        );
    }
}
