# SoledadApp – Módulo Web Servlets + JSP (GA7-220501096-AA2-EV02)

**Autor:** Oscar Herrera  
**Programa:** Tecnología en Análisis y Desarrollo de Software – SENA  
**Fecha:** 26 de julio de 2026  
**Repositorio:** https://github.com/oscarherrera/soledadapp  

---

## Descripción

Módulo web del proyecto SoledadApp que implementa CRUD completo de productos
utilizando Java Servlets y JSP. Los formularios HTML envían datos al servlet
mediante los métodos GET y POST según la operación.

## Flujo de la aplicación

| Operación | Método HTTP | URL |
|---|---|---|
| Listar productos | GET | /productos?accion=listar |
| Mostrar formulario nuevo | GET | /productos?accion=nuevo |
| Crear producto | POST | /productos (accion=nuevo) |
| Mostrar formulario editar | GET | /productos?accion=editar&id=X |
| Actualizar producto | POST | /productos (accion=editar) |
| Eliminar producto | GET | /productos?accion=eliminar&id=X |

## Tecnologías

- Java SE 17
- Jakarta Servlet API 4.0
- JSP (JavaServer Pages)
- MySQL + JDBC
- Apache Tomcat 10

## Estructura

```
SoledadApp-Web/
├── src/co/soledadapp/
│   ├── modelo/          → Producto.java
│   ├── conexion/        → ConexionBD.java
│   ├── repositorio/     → ProductoRepositorio.java
│   └── servlet/         → ProductoServlet.java
└── WebContent/
    ├── productos.jsp    → Listado de productos
    ├── formulario.jsp   → Formulario crear/editar
    └── WEB-INF/
        └── web.xml
```
