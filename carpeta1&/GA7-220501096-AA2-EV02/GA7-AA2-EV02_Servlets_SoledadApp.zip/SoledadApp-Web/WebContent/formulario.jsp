<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="co.soledadapp.modelo.Producto" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SoledadApp – Formulario de Producto</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', sans-serif; background: #F3F4F6; color: #1F2937; }

        .navbar {
            background: #7C3AED; color: white;
            padding: 14px 32px; display: flex;
            justify-content: space-between; align-items: center;
        }
        .navbar h1 { font-size: 20px; font-weight: 800; }

        .container { max-width: 600px; margin: 40px auto; padding: 0 24px; }

        .card {
            background: white; border-radius: 16px;
            padding: 36px; box-shadow: 0 4px 20px rgba(0,0,0,0.10);
        }
        .card h2 { font-size: 20px; font-weight: 700; margin-bottom: 8px; }
        .card p  { font-size: 14px; color: #6B7280; margin-bottom: 28px; }

        .form-group { margin-bottom: 20px; }
        label {
            display: block; font-size: 13px; font-weight: 600;
            color: #374151; margin-bottom: 6px;
        }
        input[type="text"], input[type="number"], select {
            width: 100%; padding: 12px 14px;
            border: 1.5px solid #E5E7EB; border-radius: 8px;
            font-size: 15px; font-family: 'Segoe UI', sans-serif;
            color: #1F2937; background: #F9FAFB;
            transition: border-color 0.2s;
            outline: none;
        }
        input:focus, select:focus {
            border-color: #7C3AED;
            background: white;
            box-shadow: 0 0 0 3px rgba(124,58,237,0.12);
        }

        .checkbox-group { display: flex; align-items: center; gap: 10px; }
        .checkbox-group input { width: auto; }
        .checkbox-group label { margin: 0; font-weight: 500; }

        .form-actions { display: flex; gap: 12px; margin-top: 28px; }
        .btn-guardar {
            flex: 1; padding: 14px;
            background: #7C3AED; color: white;
            border: none; border-radius: 8px;
            font-size: 15px; font-weight: 700;
            font-family: 'Segoe UI', sans-serif;
            cursor: pointer;
        }
        .btn-guardar:hover { background: #5B21B6; }
        .btn-cancelar {
            flex: 1; padding: 14px;
            background: white; color: #6B7280;
            border: 1.5px solid #E5E7EB; border-radius: 8px;
            font-size: 15px; font-weight: 600;
            text-decoration: none; text-align: center;
        }
        .btn-cancelar:hover { background: #F3F4F6; }
    </style>
</head>
<body>

<nav class="navbar">
    <h1>SoledadApp</h1>
</nav>

<div class="container">
    <div class="card">

        <%
            Producto producto = (Producto) request.getAttribute("producto");
            String accion     = (String) request.getAttribute("accion");
            boolean esEdicion = "editar".equals(accion);
        %>

        <h2><%= esEdicion ? "Editar Producto" : "Nuevo Producto" %></h2>
        <p><%= esEdicion ? "Modifica los datos del producto y guarda los cambios." : "Completa el formulario para registrar un nuevo producto en el catálogo." %></p>

        <%-- El formulario envía los datos al ProductoServlet mediante POST --%>
        <form action="<%= request.getContextPath() %>/productos" method="POST">

            <%-- Campo oculto que indica al servlet si es inserción o actualización --%>
            <input type="hidden" name="accion" value="<%= accion %>">

            <%-- ID del producto (solo en edición) --%>
            <% if (esEdicion) { %>
                <input type="hidden" name="idProducto" value="<%= producto.getIdProducto() %>">
            <% } %>

            <%-- Nombre del producto --%>
            <div class="form-group">
                <label for="nombreProducto">Nombre del producto</label>
                <input type="text" id="nombreProducto" name="nombreProducto"
                       placeholder="Ej: Camiseta Oversize"
                       value="<%= esEdicion ? producto.getNombreProducto() : "" %>"
                       required>
            </div>

            <%-- Categoría --%>
            <div class="form-group">
                <label for="categoria">Categoría</label>
                <select id="categoria" name="categoria" required>
                    <option value="">-- Seleccione una categoría --</option>
                    <% String[] categorias = {"Ropa", "Electrónica", "Hogar", "Alimentos", "Belleza", "Deportes"};
                       for (String cat : categorias) {
                           String selected = (esEdicion && cat.equals(producto.getCategoria())) ? "selected" : ""; %>
                    <option value="<%= cat %>" <%= selected %>><%= cat %></option>
                    <% } %>
                </select>
            </div>

            <%-- Precio de venta --%>
            <div class="form-group">
                <label for="precioVenta">Precio de venta (COP)</label>
                <input type="number" id="precioVenta" name="precioVenta"
                       placeholder="Ej: 89900" min="0" step="100"
                       value="<%= esEdicion ? (int) producto.getPrecioVenta() : "" %>"
                       required>
            </div>

            <%-- Stock disponible --%>
            <div class="form-group">
                <label for="stockDisponible">Stock disponible (unidades)</label>
                <input type="number" id="stockDisponible" name="stockDisponible"
                       placeholder="Ej: 45" min="0"
                       value="<%= esEdicion ? producto.getStockDisponible() : "" %>"
                       required>
            </div>

            <%-- Estado activo --%>
            <div class="form-group">
                <div class="checkbox-group">
                    <input type="checkbox" id="activo" name="activo"
                           <%= (esEdicion && producto.isActivo()) || !esEdicion ? "checked" : "" %>>
                    <label for="activo">Producto activo y visible en el catálogo</label>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-guardar">
                    <%= esEdicion ? "Guardar cambios" : "Crear producto" %>
                </button>
                <a href="<%= request.getContextPath() %>/productos?accion=listar" class="btn-cancelar">
                    Cancelar
                </a>
            </div>

        </form>
    </div>
</div>

</body>
</html>
