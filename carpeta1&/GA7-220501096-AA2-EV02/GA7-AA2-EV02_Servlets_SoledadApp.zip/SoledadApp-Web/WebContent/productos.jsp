<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="co.soledadapp.modelo.Producto" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SoledadApp – Gestión de Productos</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', sans-serif; background: #F3F4F6; color: #1F2937; }

        .navbar {
            background: #7C3AED; color: white;
            padding: 14px 32px; display: flex;
            justify-content: space-between; align-items: center;
        }
        .navbar h1 { font-size: 20px; font-weight: 800; }
        .navbar a { color: white; text-decoration: none; font-size: 14px; opacity: 0.85; }

        .container { max-width: 1100px; margin: 32px auto; padding: 0 24px; }

        .header-row {
            display: flex; justify-content: space-between;
            align-items: center; margin-bottom: 20px;
        }
        .header-row h2 { font-size: 22px; font-weight: 700; }

        .btn-nuevo {
            background: #7C3AED; color: white;
            padding: 10px 22px; border-radius: 8px;
            text-decoration: none; font-size: 14px; font-weight: 600;
        }
        .btn-nuevo:hover { background: #5B21B6; }

        .alerta {
            background: #D1FAE5; border: 1px solid #6EE7B7;
            color: #065F46; padding: 12px 16px;
            border-radius: 8px; margin-bottom: 20px; font-size: 14px;
        }

        table {
            width: 100%; border-collapse: collapse;
            background: white; border-radius: 12px;
            overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        thead { background: #7C3AED; color: white; }
        th, td { padding: 13px 16px; text-align: left; font-size: 14px; }
        tr:nth-child(even) { background: #F9FAFB; }
        tr:hover { background: #EDE9FE; }

        .badge {
            display: inline-block; padding: 3px 10px;
            border-radius: 99px; font-size: 12px; font-weight: 600;
        }
        .badge-activo   { background: #D1FAE5; color: #065F46; }
        .badge-inactivo { background: #FEE2E2; color: #991B1B; }

        .acciones { display: flex; gap: 8px; }
        .btn-editar  { background: #EDE9FE; color: #7C3AED; padding: 6px 14px; border-radius: 6px; text-decoration: none; font-size: 13px; font-weight: 600; }
        .btn-eliminar{ background: #FEE2E2; color: #991B1B; padding: 6px 14px; border-radius: 6px; text-decoration: none; font-size: 13px; font-weight: 600; }
        .btn-editar:hover  { background: #DDD6FE; }
        .btn-eliminar:hover{ background: #FECACA; }

        .footer { text-align: center; margin-top: 40px; color: #9CA3AF; font-size: 13px; }
    </style>
</head>
<body>

<nav class="navbar">
    <h1>SoledadApp</h1>
    <a href="productos?accion=listar">Marketplace para PyMEs · Panel Administrativo</a>
</nav>

<div class="container">
    <div class="header-row">
        <h2>Gestión de Productos</h2>
        <a href="productos?accion=nuevo" class="btn-nuevo">+ Nuevo Producto</a>
    </div>

    <%-- Mostrar mensaje de operación si existe --%>
    <% String mensaje = request.getParameter("mensaje"); %>
    <% if (mensaje != null && !mensaje.isEmpty()) { %>
        <div class="alerta">✅ <%= mensaje %></div>
    <% } %>

    <%-- Tabla de productos --%>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Categoría</th>
                <th>Precio</th>
                <th>Stock</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <%
                List<Producto> productos = (List<Producto>) request.getAttribute("productos");
                if (productos != null && !productos.isEmpty()) {
                    for (Producto p : productos) {
            %>
            <tr>
                <td><%= p.getIdProducto() %></td>
                <td><strong><%= p.getNombreProducto() %></strong></td>
                <td><%= p.getCategoria() %></td>
                <td>$<%= String.format("%,.0f", p.getPrecioVenta()) %></td>
                <td><%= p.getStockDisponible() %> uds.</td>
                <td>
                    <span class="badge <%= p.isActivo() ? "badge-activo" : "badge-inactivo" %>">
                        <%= p.isActivo() ? "Activo" : "Inactivo" %>
                    </span>
                </td>
                <td>
                    <div class="acciones">
                        <a href="productos?accion=editar&id=<%= p.getIdProducto() %>" class="btn-editar">Editar</a>
                        <a href="productos?accion=eliminar&id=<%= p.getIdProducto() %>"
                           class="btn-eliminar"
                           onclick="return confirm('¿Eliminar el producto <%= p.getNombreProducto() %>?')">
                           Eliminar
                        </a>
                    </div>
                </td>
            </tr>
            <%
                    }
                } else {
            %>
            <tr>
                <td colspan="7" style="text-align:center; color:#9CA3AF; padding:32px;">
                    No hay productos registrados. <a href="productos?accion=nuevo">Crear el primero</a>
                </td>
            </tr>
            <% } %>
        </tbody>
    </table>

    <p class="footer">SoledadApp · Oscar Herrera · SENA 2026</p>
</div>

</body>
</html>
