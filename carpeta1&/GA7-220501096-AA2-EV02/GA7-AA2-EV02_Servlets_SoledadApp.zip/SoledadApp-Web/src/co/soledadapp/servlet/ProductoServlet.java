package co.soledadapp.servlet;

import co.soledadapp.modelo.Producto;
import co.soledadapp.repositorio.ProductoRepositorio;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Servlet principal para la gestión de productos en SoledadApp.
 *
 * Maneja las peticiones HTTP GET y POST para realizar operaciones CRUD
 * sobre los productos del marketplace, delegando la lógica de acceso
 * a datos en ProductoRepositorio y redirigiendo al JSP correspondiente.
 *
 * URL de acceso: /productos
 *
 * @author Oscar Herrera
 * @version 1.0
 * @since 2026-07-26
 */
@WebServlet("/productos")
public class ProductoServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    // Repositorio de acceso a datos
    private ProductoRepositorio repositorio;

    @Override
    public void init() throws ServletException {
        super.init();
        repositorio = new ProductoRepositorio();
    }

    // ── GET: listar, mostrar formulario de edición o eliminar ───────────

    /**
     * Maneja peticiones GET. Acepta el parámetro "accion" para determinar
     * qué operación ejecutar:
     *   - listar (defecto): muestra todos los productos
     *   - editar?id=X: muestra el formulario con los datos del producto X
     *   - eliminar?id=X: elimina el producto X y redirige al listado
     *   - nuevo: muestra el formulario vacío para crear un nuevo producto
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        if (accion == null || accion.equals("listar")) {
            // Obtener todos los productos y mostrarlos
            List<Producto> productos = repositorio.listarTodos();
            request.setAttribute("productos", productos);
            request.getRequestDispatcher("/productos.jsp").forward(request, response);

        } else if (accion.equals("nuevo")) {
            // Mostrar formulario vacío para nuevo producto
            request.setAttribute("producto", new Producto());
            request.setAttribute("accion", "nuevo");
            request.getRequestDispatcher("/formulario.jsp").forward(request, response);

        } else if (accion.equals("editar")) {
            // Buscar el producto por ID y mostrar el formulario relleno
            int idProducto = Integer.parseInt(request.getParameter("id"));
            Producto producto = repositorio.buscarPorId(idProducto);

            if (producto != null) {
                request.setAttribute("producto", producto);
                request.setAttribute("accion", "editar");
                request.getRequestDispatcher("/formulario.jsp").forward(request, response);
            } else {
                request.setAttribute("mensaje", "Producto no encontrado.");
                doGet(request, response); // vuelve al listado
            }

        } else if (accion.equals("eliminar")) {
            // Eliminar el producto y volver al listado
            int idProducto = Integer.parseInt(request.getParameter("id"));
            boolean eliminado = repositorio.eliminar(idProducto);

            String mensaje = eliminado
                ? "Producto eliminado correctamente."
                : "No se pudo eliminar el producto.";

            response.sendRedirect(request.getContextPath() + "/productos?accion=listar&mensaje=" + mensaje);
        }
    }

    // ── POST: guardar (crear o actualizar) ───────────────────────────────

    /**
     * Maneja peticiones POST desde el formulario de creación y edición.
     * Determina si se trata de una inserción o actualización según el
     * valor del campo oculto "accion" en el formulario.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Establecer codificación UTF-8 para caracteres especiales en español
        request.setCharacterEncoding("UTF-8");

        // Leer los parámetros del formulario
        String accion          = request.getParameter("accion");
        String nombreProducto  = request.getParameter("nombreProducto");
        String categoria       = request.getParameter("categoria");
        double precioVenta     = Double.parseDouble(request.getParameter("precioVenta"));
        int    stockDisponible = Integer.parseInt(request.getParameter("stockDisponible"));
        boolean activo         = request.getParameter("activo") != null;

        if (accion.equals("nuevo")) {
            // Crear un nuevo producto
            Producto nuevoProducto = new Producto(
                0, nombreProducto, categoria, precioVenta, stockDisponible, activo
            );
            boolean insertado = repositorio.insertar(nuevoProducto);

            String mensaje = insertado
                ? "Producto creado exitosamente."
                : "Error al crear el producto.";

            response.sendRedirect(request.getContextPath() + "/productos?accion=listar&mensaje=" + mensaje);

        } else if (accion.equals("editar")) {
            // Actualizar un producto existente
            int idProducto = Integer.parseInt(request.getParameter("idProducto"));

            Producto productoEditado = new Producto(
                idProducto, nombreProducto, categoria, precioVenta, stockDisponible, activo
            );
            boolean actualizado = repositorio.actualizar(productoEditado);

            String mensaje = actualizado
                ? "Producto actualizado correctamente."
                : "Error al actualizar el producto.";

            response.sendRedirect(request.getContextPath() + "/productos?accion=listar&mensaje=" + mensaje);
        }
    }
}
