# SoledadApp – Módulo Frontend (GA7-220501096-AA3-EV01)

**Autor:** Oscar Herrera  
**Programa:** Tecnología en Análisis y Desarrollo de Software – SENA  
**Fecha:** 26 de julio de 2026  
**Repositorio:** https://github.com/oscarherrera/soledadapp  

---

## Descripción

Prototipo interactivo de la aplicación móvil SoledadApp desarrollado con
HTML5, CSS3 y JavaScript vanilla. Simula la interfaz de un smartphone con
tres pantallas navegables: Login, Home (catálogo) y Panel de Administración.

## Tecnologías y frameworks

- **HTML5** – estructura semántica del prototipo
- **CSS3** – variables personalizadas, Grid, Flexbox, animaciones
- **JavaScript ES6+** – renderizado dinámico, manejo de eventos, estado de UI
- **Material Icons Round** (Google Fonts) – íconos de interfaz
- **Inter** (Google Fonts) – tipografía del sistema

## Cómo ejecutar

1. Abrir `index.html` en cualquier navegador moderno
2. Usar los botones flotantes (Login / Home / Admin) para navegar entre pantallas
3. Interactuar con el catálogo: filtrar categorías, agregar al carrito, marcar favoritos

## Pantallas implementadas

| Pantalla | Descripción |
|---|---|
| Login | Autenticación con correo/contraseña, toggle de visibilidad, acceso a Admin |
| Home | Catálogo con categorías, banner de oferta, carrito, favoritos |
| Admin | Dashboard con métricas, gráfico de ventas, pedidos y stock |

## Repositorio Git

```bash
git clone https://github.com/oscarherrera/soledadapp.git
cd soledadapp
# Abrir index.html en el navegador
```
